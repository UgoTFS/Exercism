public interface RemoteControlCar {
    // TODO implement the RemoteControlCar interface

    void drive();
    int getDistanceTravelled();
}
